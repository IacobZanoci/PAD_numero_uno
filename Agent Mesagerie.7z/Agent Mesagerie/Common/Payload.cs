﻿namespace Common
{
    public class Payload
    {
        public string Topic { get; set; }
        public string Message { get; set; }
    }
}
